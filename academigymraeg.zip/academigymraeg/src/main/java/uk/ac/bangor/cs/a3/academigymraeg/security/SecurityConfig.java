package uk.ac.bangor.cs.a3.academigymraeg.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;
@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/", "/index.html", "/css/**", "/js/**").permitAll()
                
                .requestMatchers("/admin/**").hasRole("ADMINISTRATOR")
                
                .requestMatchers("/nouns/manage/**").hasRole("INSTRUCTOR")
                
                .requestMatchers("/test/**", "/results/**").hasRole("STUDENT")
                
                .anyRequest().authenticated()
            )
            .formLogin(form -> form
                .defaultSuccessUrl("/", true)
                .permitAll()
            )
            .logout(logout -> logout.permitAll());

        return http.build();
    }
    @Bean
    public org.springframework.security.core.userdetails.UserDetailsService users() {
        return new org.springframework.security.provisioning.InMemoryUserDetailsManager(
            org.springframework.security.core.userdetails.User.withDefaultPasswordEncoder()
                .username("student")
                .password("1234")
                .roles("STUDENT")
                .build(),

            org.springframework.security.core.userdetails.User.withDefaultPasswordEncoder()
                .username("instructor")
                .password("1234")
                .roles("INSTRUCTOR")
                .build(),

            org.springframework.security.core.userdetails.User.withDefaultPasswordEncoder()
                .username("admin")
                .password("1234")
                .roles("ADMINISTRATOR")
                .build()
        );
    }
    }
