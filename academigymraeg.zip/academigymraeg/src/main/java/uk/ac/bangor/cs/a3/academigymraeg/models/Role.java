package uk.ac.bangor.cs.a3.academigymraeg.models;

public enum Role {
    ROLE_STUDENT,
    ROLE_INSTRUCTOR,
    ROLE_ADMINISTRATOR
}